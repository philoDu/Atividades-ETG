// Lista de Tarefas Interativa - Exercício Prático
// Encontro 4: Manipulação do DOM 1

const itens = document.querySelectorAll('#lista-tarefas li');

itens.forEach(item => {
    item.addEventListener('click', function() {
        this.classList.toggle('concluida');

        if (this.classList.contains('concluida')) {
            abrirModal(`Tarefa "${this.textContent}" marcada como concluída!`);
        } else {
            abrirModal(`Tarefa "${this.textContent}" desmarcada.`);
        }
    })
})


const modal = document.querySelector('#modal');
const modalMensagem = document.querySelector('#modal-mensagem');
const modalFechar = document.querySelector('#modal-fechar');

function abrirModal(mensagem) {
    modalMensagem.textContent = mensagem;
    modal.classList.add('ativo');
}

modalFechar.addEventListener('click', function() {
    modal.classList.remove('ativo');
});

