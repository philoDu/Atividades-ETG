// Arquivo base para o exercício de programação assíncrona
// Complete as funções abaixo seguindo as instruções

const listaProdutos = document.querySelector("#lista-produtos");
const status = document.querySelector("#status");
const produtosCarregados = [
    {
        id: "200137", nome: "Notebook Dell Inspiron 15", quantidade: 13
    },
    {
        id: "201023", nome: "Mouse Logitech G203 Lightsync", quantidade: 23
    },
    {
        id: "100256", nome: "Teclado Mecânico HyperX Alloy Origins", quantidade: 25
    },
    {
        id: "000747", nome: "Monitor AOC AGON QUAD CQ32G4E 32pol", quantidade: 10
    }
];


function buscarProdutos() {

    return new Promise((resolve, reject) => {

        setTimeout(() => {

            const sucesso = Math.random();

            if (sucesso < 0.8) {
                resolve(produtosCarregados);
            } else {
                reject(new Error('Falha ao conectar com o servidor.'));
            }

        }, 2000);

    });
    
}

function carregarProdutos() {
    // TODO: Atualizar o elemento #status para "Carregando..."
    status.innerHTML = "Carregando...";
    status.classList.remove("error");
    status.classList.add("loading");

    // TODO: Limpar a lista de produtos
    listaProdutos.innerHTML = "";
    
    // TODO: Chamar buscarProdutos()
    // TODO: Usar .then() para tratar o sucesso
    buscarProdutos()
        .then((produtos) => {
            status.classList.remove("loading", "error");
            status.innerHTML = "Sucesso!";
            listaProdutos.innerHTML = produtos
                .map(produto => `
                    <li>
                        ${produto.id} - ${produto.nome} - Estoque: ${produto.quantidade}
                    </li>`)
                .join('');
        })

        .catch((erro) => {
            status.innerHTML = erro.message;
            status.classList.remove("loading");
            status.classList.add("error");

        });

}

