
const form = document.querySelector('#form-cadastro');
const usuario = document.querySelector('#usuario');
const email = document.querySelector('#email');
const senha = document.querySelector('#senha');
const confirmarSenha = document.querySelector('#confirmar-senha');

const feedbackUsuario = document.querySelector('#feedback-usuario');
const feedbackEmail = document.querySelector('#feedback-email');
const feedbackSenha = document.querySelector('#feedback-senha');
const feedbackConfirmarSenha = document.querySelector('#feedback-confirmar-senha');


// Aplica/remove as classes visuais (.valido / .invalido / .erro / .sucesso)
// definidas no CSS, mantendo os indicadores de cor consistentes em todos os campos.
function atualizarCampo(input, feedbackEl, valido, mensagem) {
    input.classList.toggle('valido', valido);
    input.classList.toggle('invalido', !valido);

    feedbackEl.textContent = mensagem;
    feedbackEl.classList.toggle('sucesso', valido);
    feedbackEl.classList.toggle('erro', !valido);
}

function limparCampo(input, feedbackEl) {
    input.classList.remove('valido', 'invalido');
    feedbackEl.textContent = '';
    feedbackEl.classList.remove('sucesso', 'erro');
}

function validarUsuario() {
    if (usuario.value.length === 0) {
        limparCampo(usuario, feedbackUsuario);
        return false;
    }

    const valido = usuario.value.length >= 3;
    atualizarCampo(usuario, feedbackUsuario, valido,
        valido ? '✓ Nome de usuário válido.' : '✗ Faltam caracteres para completar o mínimo.'
    );
    return valido;
}

function validarEmail() {
    if (email.value.length === 0) {
        limparCampo(email, feedbackEmail);
        return false;
    }

    const valido = email.value.includes('@');
    atualizarCampo(email, feedbackEmail, valido,
        valido ? '✓ E-mail válido.' : '✗ Formato inválido, verifique o "@".'
    );
    return valido;
}

function validarSenha() {
    const temOitoCaracteres = senha.value.length >= 8;
    const temMaiuscula = /[A-Z]/.test(senha.value);
    const temMinuscula = /[a-z]/.test(senha.value);
    const temNumero = /[0-9]/.test(senha.value);

    return temOitoCaracteres && temMaiuscula && temMinuscula && temNumero;
}

function atualizarChecklistSenha() {
    if (senha.value.length === 0) {
        limparCampo(senha, feedbackSenha);
        return false;
    }

    const temOitoCaracteres = senha.value.length >= 8;
    const temMaiuscula = /[A-Z]/.test(senha.value);
    const temMinuscula = /[a-z]/.test(senha.value);
    const temNumero = /[0-9]/.test(senha.value);
    const valida = temOitoCaracteres && temMaiuscula && temMinuscula && temNumero;

    const criterio = (ok, texto) => `<li class="${ok ? 'ok' : 'falta'}">${ok ? '✓' : '✗'} ${texto}</li>`;

    feedbackSenha.innerHTML = `<ul class="checklist">
        ${criterio(temOitoCaracteres, 'Pelo menos 8 caracteres')}
        ${criterio(temMaiuscula, 'Uma letra maiúscula')}
        ${criterio(temMinuscula, 'Uma letra minúscula')}
        ${criterio(temNumero, 'Um número')}
    </ul>`;

    senha.classList.toggle('valido', valida);
    senha.classList.toggle('invalido', !valida);
    feedbackSenha.classList.toggle('sucesso', valida);
    feedbackSenha.classList.toggle('erro', !valida);

    return valida;
}

function validarConfirmarSenha() {
    if (confirmarSenha.value.length === 0) {
        limparCampo(confirmarSenha, feedbackConfirmarSenha);
        return false;
    }

    const conferem = confirmarSenha.value === senha.value;
    atualizarCampo(confirmarSenha, feedbackConfirmarSenha, conferem,
        conferem ? '✓ As senhas coincidem.' : '✗ As senhas não coincidem.'
    );
    return conferem;
}

usuario.addEventListener('input', validarUsuario);
email.addEventListener('input', validarEmail);

senha.addEventListener('input', () => {
    atualizarChecklistSenha();
    if (confirmarSenha.value !== '') {
        validarConfirmarSenha();
    }
});

confirmarSenha.addEventListener('input', validarConfirmarSenha);

form.addEventListener('submit', (event) => {
    event.preventDefault();

    const usuarioValido = validarUsuario();
    const emailValido = validarEmail();
    const senhaValida = atualizarChecklistSenha();
    const senhasConferem = validarConfirmarSenha();

    if (!usuarioValido || !emailValido || !senhaValida || !senhasConferem) {
        return;
    }

    alert('Tudo certo! Cadastro realizado com sucesso.');
});
