// Calculadora Simples - Exercício Prático
// Encontro 2: Estruturas Condicionais, Loops, Funções e Arrow Functions

// TODO: Passo 2 - Crie quatro Arrow Functions para as operações básicas
// Exemplo: const somar = (a, b) => a + b;

const somar = (a, b) => a + b;

const subtrair = (a, b) => a - b;

const multiplicar = (a, b) => a * b;

const dividir = (a, b) => a / b;


// TODO: Passo 3 - Crie a função principal 'calcular'
// Esta função deve receber três parâmetros: numero1, numero2 e operador
// Use uma estrutura switch para verificar o operador e chamar a função correspondente

function calcular(numero1, numero2, operador) {
    switch (operador) {
        case "+":
            return somar(numero1, numero2)
        break;
        
        case "-":
            return subtrair(numero1, numero2)
        break;
       
        case "*":
            return multiplicar(numero1, numero2)
        break;
        
        case "/":
            return dividir(numero1, numero2)
        break;

        default:
            return "ERRO: 'operador' deve ser um dos quatro operadores matemáticos básicos."
    }
    
}

// TODO: Passo 4 - Teste a calculadora
// Chame a função calcular com diferentes valores e operadores
// Use console.log() e template literals para exibir os resultados

// Exemplo: console.log(`Resultado de 10 + 5 é: ${calcular(10, 5, "+")}`);

