// Arquivo: main.js (ES5 - Código Antigo)

// Passo 2: Altere a declaração da função para usar Destructuring e Arrow Functions
const calcularPrecoFinal = (produto, config) => {

  //desctructuring para criar as variáveis
  const { preco: precoBase } = produto;
  const { desconto, imposto } = config;

  //validação cronta falsy usando OR
  const descontoFinal = desconto || 0;
  const impostoFinal = imposto || 0;

  //cálculo
  const precoComDesconto = precoBase * (1 - descontoFinal);
  const precoFinal = precoComDesconto * (1 + impostoFinal);

  return precoFinal;

}

const produto = {
  nome: "Notebook",
  preco: 2500,
  categoria: "Eletrônicos"
};

const configCliente = {
  desconto: 0.10, // 10%
  imposto: 0.05   // 5%
};

const precoFinal = calcularPrecoFinal(produto, configCliente);

// Passo 3: Altere a declaração da mensagem para usar Template Literals

const mensagem = `O preço final do produto ${produto.nome} é R$ ${precoFinal.toFixed(2)}.`;

console.log(mensagem);

// Passo 4: Crie e exiba na console um novo objeto produtoComPrecoFinal que contenha todas 
// as propriedades do objeto produto original, mais a propriedade precoFinal, utilizando o 
// operador Spread.

const produtoComPrecoFinal = {
  ...produto,
  precoFinal
}

console.log(produtoComPrecoFinal);