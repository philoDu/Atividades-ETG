// Solução completa do exercício de Lista de Tarefas Interativa

// Array para armazenar as tarefas
let tarefas = [];
let proximoId = 1;

// Elementos do DOM
const formTarefa = document.getElementById('form-tarefa');
const inputTarefa = document.getElementById('input-tarefa');
const btnAdicionar = document.getElementById('btn-adicionar');
const listaTarefas = document.getElementById('lista-tarefas');
const mensagemVazia = document.getElementById('mensagem-vazia');
const notificacao = document.getElementById('notificacao');

// Função para mostrar notificações
function mostrarNotificacao(mensagem, tipo = 'sucesso') {
    notificacao.textContent = mensagem;
    notificacao.className = `notificacao ${tipo}`;
    
    // Remove a notificação após 3 segundos
    setTimeout(() => {
        notificacao.className = 'notificacao';
    }, 3000);
}

// Função para criar componente de tarefa (reutilizável)
function criarComponenteTarefa(tarefa) {
    const li = document.createElement('li');
    li.className = 'tarefa';
    
    // Adiciona classe se concluída
    if (tarefa.concluida) {
        li.classList.add('concluida');
    }
    
    // Texto da tarefa
    const span = document.createElement('span');
    span.className = 'tarefa-texto';
    span.textContent = tarefa.texto;
    
    // Container dos botões
    const acoes = document.createElement('div');
    acoes.className = 'tarefa-acoes';
    
    // Botão concluir
    const btnConcluir = document.createElement('button');
    btnConcluir.className = 'btn-concluir';
    btnConcluir.textContent = tarefa.concluida ? 'Desfazer' : 'Concluir';
    btnConcluir.setAttribute('data-id', tarefa.id);
    
    // Botão remover
    const btnRemover = document.createElement('button');
    btnRemover.className = 'btn-remover';
    btnRemover.textContent = 'Remover';
    btnRemover.setAttribute('data-id', tarefa.id);
    
    // Monta o componente
    acoes.appendChild(btnConcluir);
    acoes.appendChild(btnRemover);
    li.appendChild(span);
    li.appendChild(acoes);
    
    return li;
}

// Função para renderizar todas as tarefas
function renderizarTarefas() {
    // Limpa a lista atual
    listaTarefas.innerHTML = '';
    
    // Se não há tarefas, mostra mensagem vazia
    if (tarefas.length === 0) {
        mensagemVazia.classList.add('visivel');
        return;
    }
    
    // Esconde mensagem vazia
    mensagemVazia.classList.remove('visivel');
    
    // Renderiza cada tarefa
    tarefas.forEach(tarefa => {
        const componenteTarefa = criarComponenteTarefa(tarefa);
        listaTarefas.appendChild(componenteTarefa);
    });
}

// Função para adicionar nova tarefa
function adicionarTarefa(texto) {
    const novaTarefa = {
        id: proximoId++,
        texto: texto.trim(),
        concluida: false
    };
    
    tarefas.push(novaTarefa);
    renderizarTarefas();
    mostrarNotificacao('Tarefa adicionada com sucesso!', 'sucesso');
}

// Função para alternar status da tarefa
function alternarTarefa(id) {
    const tarefa = tarefas.find(t => t.id === parseInt(id));
    
    if (tarefa) {
        tarefa.concluida = !tarefa.concluida;
        renderizarTarefas();
        
        const mensagem = tarefa.concluida ? 
            'Tarefa marcada como concluída!' : 
            'Tarefa desmarcada!';
        mostrarNotificacao(mensagem, 'sucesso');
    }
}

// Função para remover tarefa
function removerTarefa(id) {
    tarefas = tarefas.filter(t => t.id !== parseInt(id));
    renderizarTarefas();
    mostrarNotificacao('Tarefa removida!', 'sucesso');
}

// Simular carregamento ao adicionar tarefa
async function simularCarregamento() {
    const textoBtn = btnAdicionar.querySelector('.texto');
    const spinnerBtn = btnAdicionar.querySelector('.spinner');
    
    // Mostra spinner
    textoBtn.style.display = 'none';
    spinnerBtn.style.display = 'inline-block';
    btnAdicionar.disabled = true;
    
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Esconde spinner
    textoBtn.style.display = 'inline-block';
    spinnerBtn.style.display = 'none';
    btnAdicionar.disabled = false;
}

// Event listener para o formulário
formTarefa.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const texto = inputTarefa.value.trim();
    
    if (texto === '') {
        mostrarNotificacao('Por favor, digite uma tarefa!', 'erro');
        return;
    }
    
    // Simula carregamento
    await simularCarregamento();
    
    // Adiciona a tarefa
    adicionarTarefa(texto);
    
    // Limpa o input
    inputTarefa.value = '';
    inputTarefa.focus();
});

// Event listener para a lista (delegação de eventos)
listaTarefas.addEventListener('click', function(e) {
    const id = e.target.getAttribute('data-id');
    
    if (!id) return;
    
    if (e.target.classList.contains('btn-concluir')) {
        alternarTarefa(id);
    } else if (e.target.classList.contains('btn-remover')) {
        removerTarefa(id);
    }
});

// Renderização inicial
renderizarTarefas();

// Foca no input ao carregar a página
inputTarefa.focus();

