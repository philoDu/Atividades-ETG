
const status = document.querySelector("#status");
const lista = document.querySelector("#lista-tarefas");

async function buscarTarefas() {

    const url = "https://jsonplaceholder.typicode.com/todos";
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Erro HTTP! Status: ${response.status}`);
        }

        const result = await response.json();
        return result;
    
    
    } catch (error) {
        console.error("Falha em buscarTarefas:", error);
        throw error;
    }
    
}




async function carregarTarefas() {
    status.textContent = "Carregando tarefas...";
    lista.textContent = "";

    try {
        const tarefas = await buscarTarefas();
        status.textContent = "";
        tarefas.forEach((tarefa) => {
            const li = document.createElement("li");
            li.textContent = tarefa.title;
            lista.appendChild(li);
        });

    } catch (error) {
        status.textContent = error.message;
    }
}

