// Sistema de Cadastro de Livros - Exercício Prático
// Encontro 3: Objetos e Classes

// TODO: Passo 2 - Crie a classe Livro
// A classe deve ter um construtor que recebe titulo, autor e anoPublicacao
// Adicione um método detalhes() que exibe as informações do livro

class Livro {
    // TODO: Implemente o construtor aqui
    constructor(titulo, autor, anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
    }

    // TODO: Implemente o método detalhes() aqui
    detalhes() {
        console.log(`O livro ${this.titulo} foi escrito por ${this.autor} e publicado em ${this.anoPublicacao}`)
    }
    
}

// TODO: Passo 3 - Crie a classe Biblioteca
// A classe deve ter um construtor que inicializa um array vazio chamado acervo
// Adicione os métodos adicionarLivro(livro) e listarLivros()

class Biblioteca {
    // TODO: Implemente o construtor aqui
    constructor() {
        this.acervo = [];
    }
    // TODO: Implemente o método adicionarLivro(livro) aqui
    adicionarLivro(livro) {
        this.acervo.push(livro);
        console.log(`Livro "${livro.titulo}" adicionado à biblioteca.`);
    }
    
    // TODO: Implemente o método listarLivros() aqui
    listarLivros() {
        console.log("=== Acervo da Biblioteca ===");

        let numero = 1;

        for (let livro of this.acervo) {
            console.log(`${numero}. "${livro.titulo}" por ${livro.autor} (${livro.anoPublicacao})`);
            numero++;
        }
    }
    
}

// TODO: Passo 4 - Teste o sistema
// Crie uma instância da Biblioteca
// Crie pelo menos três instâncias da classe Livro
// Adicione os livros à biblioteca
// Liste os livros no console

const biblioteca = new Biblioteca();

const livro1 = new Livro("1984", "George Orwell", 1949);
const livro2 = new Livro("Dom Casmurro", "Machado de Assis", 1899);
const livro3 = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943);

biblioteca.adicionarLivro(livro1);
biblioteca.adicionarLivro(livro2);
biblioteca.adicionarLivro(livro3);

biblioteca.listarLivros();