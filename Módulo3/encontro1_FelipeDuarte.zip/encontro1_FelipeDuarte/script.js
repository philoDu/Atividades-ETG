// Calculadora de Média - Exercício Prático
// Encontro 1: Fundamentos do JavaScript

// TODO: Passo 2 - Declare três constantes para as notas
// Exemplo: const nota1 = 7;
const nota1 = 6.7;
const nota2 = 5.34;
const nota3 = 9.13;




// TODO: Passo 3 - Calcule a média das três notas
// Dica: media = (nota1 + nota2 + nota3) / 3

let media = (nota1 + nota2 + nota3) / 3;


// TODO: Passo 4 - Exiba o resultado no console
// Use console.log() para mostrar a média calculada

console.log(media.toFixed(2));


